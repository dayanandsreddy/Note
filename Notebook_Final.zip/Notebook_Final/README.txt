Notes- 

brief: 

Web application to create a online note which is user specific.

Technologies :

Front-End: HTML, CSS, JS
library: jQuery
Back End: PHP, MySql
Server: Apache

Working:

- using above Technologies(HTML, CSS, JS, jQuery) UI has been created and accepts USER_NAME, PASSWORD if your not new user USER/helps to create new USER details(forms).
- Data(USER_NAME, PASSWORD) stored in specific data base, I have used (https://in.000webhost.com) a free hosting website to host and  to store my data as which supports PHP and mySQL.
- user can have their own sticky notes which can be updated.

