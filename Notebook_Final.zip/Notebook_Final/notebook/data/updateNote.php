<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 21/11/18
 * Time: 2:09 PM
 */
include("config.php");
include ('StickyNotes.php');
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $userId = $_POST['id'];
    $head = $_POST['note_head'];
    $content = $_POST['note_content'];

    $createNote = new StickyNotes();
    $createNote->updateNote($db,$userId,$head,$content);
    $response = array('code'=>200,'message'=>'Note Updated Successfully');

    echo json_encode($response);
}
?>