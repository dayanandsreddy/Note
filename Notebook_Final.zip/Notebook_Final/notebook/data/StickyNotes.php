<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 21/11/18
 * Time: 12:41 AM
 */

class StickyNotes{
    public function getAllUserStickyNotes($db,$id){
        $sql = "SELECT * FROM sticky_notes WHERE user_id = ".$id;
        $result = $db->query($sql);
        $notesCollectionData = array();
        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()){
                array_push($notesCollectionData,$row);
            }
            return $notesCollectionData;
        } else {
            return null;
        }
    }
    public function createNewNote($db,$id,$head,$content){
        $sql = "INSERT INTO sticky_notes (user_id, heading, content) VALUES ('".$id."', '".$head."','".$content."')";
        $db->query($sql);
    }

    public function updateNote($db,$id,$head,$content){
        $sql = "UPDATE sticky_notes SET heading = '".$head."', content = '".$content."' WHERE id = ".$id;
        $db->query($sql);
    }
}