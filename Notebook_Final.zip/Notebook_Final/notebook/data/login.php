<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 20/11/18
 * Time: 11:29 PM
 */

include("config.php");
session_start();
class userLogin {

    /**
     * @param $db
     * @param $userdata
     * @return bool
     */
    public function login($db,$email,$password){
        $sql = "SELECT * FROM users WHERE user_email = '".$email."'  AND user_password = '".$password."'";
        $result = $db->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row;
        } else {
            return false;
        }
    }

}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $userEmail = $_POST['email'];
    $password = $_POST['password'];



    $userlogin = new userLogin();

    $userData = $userlogin->login($db,$userEmail,$password);
    $response = array();

    if($userData != false){
        $_SESSION['user_details'] = $userData;
        $response = array('code'=>200,'message'=>'Login Successfully');

    }else{
        $response = array('code'=>500,'message'=>'Unable to LogIn into your Account');
    }

    echo json_encode($response);
}